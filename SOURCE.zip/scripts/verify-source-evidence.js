// Read-only verification of retained public evidence. No network, account or paid API.
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import path from 'node:path';
import { APP_ROOT } from './serve.js';
import { BASELINES, SHORT_TON_KG, WARM_BACKGROUND_SHA256, WARM_CONTAINERS_SHA256 } from '../lib/baselines.js';

export async function verifySourceEvidence() {
  const dir = path.join(APP_ROOT, 'evidence', 'source-baselines');
  const proof = JSON.parse(await readFile(path.join(dir, 'verified-baselines.json'), 'utf8'));
  for (const source of proof.sources) {
    assert.equal(source.httpStatus, 200, source.id);
    const bytes = await readFile(path.join(APP_ROOT, source.file));
    assert.equal(createHash('sha256').update(bytes).digest('hex'), source.sha256, source.id + ' bytes changed');
  }
  assert.equal(proof.sources.find(source => source.id === 'epa-warm-background-v16').sha256, WARM_BACKGROUND_SHA256);
  assert.equal(proof.sources.find(source => source.id === 'epa-warm-containers-v16').sha256, WARM_CONTAINERS_SHA256);
  for (const quote of proof.quotes) {
    const content = JSON.parse(await readFile(path.join(dir, quote.pagesFile), 'utf8'))[quote.pdfPage - 1].replace(/\s+/g, ' ').trim();
    assert.ok(content.includes(quote.normalizedQuote), quote.id + ' quote not retained');
  }
  const nist = await readFile(path.join(dir, 'nist-si-b8-verified.txt'), 'utf8');
  assert.ok(nist.includes('ton, short (2000 lb) kilogram (kg) 9.071 847 E+02'));
  assert.equal(SHORT_TON_KG, proof.conversion.shortTonKg);
  for (const baseline of proof.baselines) assert.deepEqual(BASELINES[baseline.id].rawCarbon, baseline.rawCarbon);
  return { verifiedSources: proof.sources.length, verifiedQuotes: proof.quotes.length, baselines: proof.baselines.map(item => item.id), networkRequests: 0 };
}
if (process.argv[1]?.endsWith('verify-source-evidence.js')) console.log(JSON.stringify(await verifySourceEvidence(), null, 2));
