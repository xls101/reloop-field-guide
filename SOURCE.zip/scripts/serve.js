import http from 'node:http';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
export const APP_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const types = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.webp': 'image/webp', '.webmanifest': 'application/manifest+json' };
const exposed = name => ['index.html', 'styles.css', 'app.js', 'sw.js', 'manifest.webmanifest'].includes(name) || /^(lib\/[a-z0-9-]+\.js|assets\/[a-z0-9-]+\.(svg|png|jpg|webp))$/i.test(name);
export function makeServer({ root = APP_ROOT, base = '/' } = {}) {
  if (!/^\/(?:[a-zA-Z0-9_-]+\/)*$/.test(base)) throw new RangeError('Use a safe trailing-slash base path.');
  return http.createServer(async (request, response) => {
    const send = (status, body, headers = {}) => { response.writeHead(status, { 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', ...headers }); response.end(request.method === 'HEAD' ? undefined : body); };
    if (!['GET', 'HEAD'].includes(request.method)) return send(405, 'Method not allowed', { Allow: 'GET, HEAD' });
    let pathname;
    try { pathname = decodeURIComponent(request.url.split('?')[0]); } catch { return send(400, 'Bad path'); }
    if (pathname === base.slice(0, -1) && base !== '/') return send(308, '', { Location: base });
    if (!pathname.startsWith(base) || pathname.includes('\\') || pathname.split('/').includes('..') || pathname.includes('\0')) return send(404, 'Not found');
    const relative = pathname.slice(base.length) || 'index.html';
    if (!exposed(relative)) return send(404, 'Not found');
    try { const buffer = await readFile(path.join(root, relative)); send(200, buffer, { 'Content-Type': types[path.extname(relative)] ?? 'application/octet-stream' }); }
    catch { send(404, 'Not found'); }
  });
}
if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  const port = Number(process.env.PORT ?? 4178);
  if (!Number.isInteger(port) || port < 0 || port > 65535) throw new RangeError('PORT must be 0–65535.');
  const server = makeServer();
  server.on('error', error => { console.error('Local preview failed:', error.message); process.exitCode = 1; });
  server.listen(port, '127.0.0.1', () => console.log('ReLoop LOCAL_ONLY preview: http://127.0.0.1:' + server.address().port + '/'));
  for (const signal of ['SIGINT', 'SIGTERM']) process.on(signal, () => server.close(() => process.exit(0)));
}
