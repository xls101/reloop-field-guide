import { cp, mkdir, rm } from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { APP_ROOT } from './serve.js';
export const PUBLIC_FILES = ['index.html', 'styles.css', 'app.js', 'sw.js', 'manifest.webmanifest', 'lib', 'assets'];
export async function prepareSite() {
  const output = path.join(APP_ROOT, '_site');
  await rm(output, { recursive: true, force: true });
  await mkdir(output, { recursive: true });
  for (const file of PUBLIC_FILES) await cp(path.join(APP_ROOT, file), path.join(output, file), { recursive: true });
  return output;
}
if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) console.log('Local static build only (not deployed): ' + await prepareSite());
