import test from 'node:test';
import assert from 'node:assert/strict';
import { BASELINES, SHORT_TON_KG } from '../lib/baselines.js';
import { LEGACY_MODEL_VERSION, MODEL_VERSION } from '../lib/data.js';
import { calculateScenario, getBaseline, matchesBaseline, validateDraft } from '../lib/model.js';
import { draft, fakeStorage } from './fixture.js';
import { createRecord, isRecord, loadShelf, saveShelf, STORAGE_KEY, upsertRecord } from '../lib/storage.js';
import { buildPoster, buildReport } from '../lib/report.js';
import { verifySourceEvidence } from '../scripts/verify-source-evidence.js';

const glass = values => draft({ name: 'Empty container glass jar', category: 'glass', baseline: 'warm_glass_v16', baselineConfirmed: true, mass: 0.35, price: 4, cost: 0, displacement: 100, ...values });
const pet = values => draft({ name: 'PET #1 bottle', category: 'plastic', baseline: 'warm_pet_v16', baselineConfirmed: true, mass: 0.03, price: 2, cost: 0, displacement: 100, ...values });
const near = (actual, expected) => assert.ok(Math.abs(actual - expected) < 1e-12, actual + ' versus ' + expected);
const date = '2026-11-25T05:00:00.000Z';

test('published EPA values retain exact source units and distinct input cases', () => {
  assert.deepEqual(BASELINES.warm_glass_v16.rawCarbon, [0.53, 0.60]);
  assert.deepEqual(BASELINES.warm_pet_v16.rawCarbon, [2.17, 2.21]);
  assert.equal(BASELINES.warm_pet_v16.rawUnit, 'MTCO2e / US short ton of material');
  assert.equal(BASELINES.warm_glass_v16.published, 'December 2023');
  assert.deepEqual(BASELINES.warm_glass_v16.endpointLabels, ['WARM current mix of inputs', '100% virgin inputs']);
});
test('NIST table conversion changes metric-ton numerator and US-short-ton denominator correctly', () => {
  assert.equal(SHORT_TON_KG, 907.1847);
  near(getBaseline(glass()).carbon[0], 0.53 * 1000 / 907.1847);
  near(getBaseline(pet()).carbon[1], 2.21 * 1000 / 907.1847);
});
test('new draft defaults to no verified environmental baseline, never a universal factor', () => {
  const input = draft(); delete input.baseline; delete input.baselineConfirmed;
  const value = validateDraft(input).value;
  assert.equal(value.baseline, 'none'); assert.equal(value.modelVersion, MODEL_VERSION);
  const impact = calculateScenario(input); assert.equal(impact.carbon, null); assert.equal(impact.water, null); assert.equal(impact.money, 9.5); assert.equal(impact.displacementEnabled, true);
});
test('only named container glass and PET resin have defensible source mappings', () => {
  assert.equal(matchesBaseline('warm_glass_v16', 'empty glass jar', 'glass'), true);
  assert.equal(matchesBaseline('warm_pet_v16', 'PET #1 bottle', 'plastic'), true);
  for (const name of ['plastic bottle', 'PETG bottle', 'mixed PET bottle', 'PET multilayer container', 'polyester jacket']) assert.equal(matchesBaseline('warm_pet_v16', name, 'plastic'), false, name);
  for (const name of ['glass', 'glass window', 'ceramic jar', 'drinking glass jar', 'borosilicate glass jar', 'glass mirror bottle']) assert.equal(matchesBaseline('warm_glass_v16', name, 'glass'), false, name);
});
test('wrong category, nonexistent and prototype baseline keys cannot be used', () => {
  for (const input of [glass({ category: 'textile' }), glass({ baseline: 'constructor' }), pet({ baseline: 'made-up-lca' })]) assert.equal(validateDraft(input).ok, false);
});
test('source selection still requires explicit matching/material-boundary confirmation', () => {
  assert.equal(validateDraft(glass({ baselineConfirmed: false })).ok, false);
  assert.equal(validateDraft(glass({ baselineConfirmed: 'true' })).ok, false);
  assert.equal(validateDraft(glass()).ok, true);
});
test('glass source scenario is exact mass × source × quantity × displacement, not disposal benefit', () => {
  const value = calculateScenario(glass({ quantity: 2, displacement: 50 }));
  near(value.carbon[0], 2 * 0.35 * 0.5 * 0.53 * 1000 / SHORT_TON_KG);
  near(value.carbon[1], 2 * 0.35 * 0.5 * 0.60 * 1000 / SHORT_TON_KG);
  assert.equal(value.money, 4); assert.equal(value.water, null); assert.match(value.reason, /not a measured, net or marginal/);
});
test('PET uses published total 2.21, not sum of rounded component cells', () => {
  const value = calculateScenario(pet({ quantity: 4, displacement: 25 }));
  near(value.carbon[1], 4 * 0.03 * 0.25 * 2.21 * 1000 / SHORT_TON_KG);
  assert.notEqual(BASELINES.warm_pet_v16.rawCarbon[1], 1.72 + 0.11 + 0.39);
  assert.match(value.baseline.boundary, /NOT included/); assert.match(value.baseline.exclusions, /bottle forming/);
});
test('published source carbon responds monotonically to displacement without inventing water', () => {
  for (const make of [glass, pet]) {
    let last = -1;
    for (const displacement of [0, 25, 50, 75, 100]) { const result = calculateScenario(make({ displacement })); assert.ok(result.carbon[0] >= last); assert.equal(result.water, null); last = result.carbon[0]; }
  }
});
test('source zero displacement has zero carbon but still includes entered repair/route cost', () => {
  const value = calculateScenario(glass({ displacement: 0, cost: 3 })); assert.deepEqual(value.carbon, [0, 0]); assert.equal(value.money, -3); assert.equal(value.water, null);
});
test('source-backed selection cannot override recycling or safety exclusion', () => {
  const recycle = calculateScenario(pet({ action: 'recycle', cost: 2 })); assert.equal(recycle.carbon, null); assert.equal(recycle.water, null); assert.equal(recycle.money, -2);
  for (const input of [glass({ name: 'cracked glass jar' }), pet({ condition: 'unsafe' })]) { const value = calculateScenario(input); assert.equal(value.carbon, null); assert.equal(value.water, null); assert.equal(value.money, null); }
});
test('unsupported item cannot borrow an illustrative water factor alongside an EPA source', () => {
  const value = calculateScenario(pet({ water: [999, 999], carbon: [999, 999] }));
  assert.equal(value.water, null); assert.ok(value.carbon[1] < 0.1); assert.match(value.baseline.waterNote, /Green, blue, grey/);
});
test('legacy v1 snapshot opens with its original illustrative arithmetic and no silent source upgrade', () => {
  const input = draft({ modelVersion: LEGACY_MODEL_VERSION, id: 'legacy-one', createdAt: date, updatedAt: date }); delete input.baseline; delete input.baselineConfirmed;
  assert.equal(isRecord(input), true);
  const original = JSON.stringify({ version: 1, entries: [input] }); const storage = fakeStorage({ [STORAGE_KEY]: original });
  const loaded = loadShelf(storage); assert.equal(loaded.mode, 'persistent'); assert.equal(storage.getItem(STORAGE_KEY), original);
  const value = calculateScenario(loaded.entries[0]); assert.deepEqual(value.carbon, [0.625, 2.5]); assert.deepEqual(value.water, [125, 625]); assert.equal(value.baseline.id, 'illustrative'); assert.equal(value.modelVersion, LEGACY_MODEL_VERSION);
});
test('a mixed legacy/v2 shelf round-trips without dropping identity, inputs or original timestamps', () => {
  const legacy = draft({ modelVersion: LEGACY_MODEL_VERSION, id: 'legacy-two', createdAt: date, updatedAt: date }); delete legacy.baseline; delete legacy.baselineConfirmed;
  const sourced = createRecord(glass(), 'source-one', date); const storage = fakeStorage(); assert.equal(saveShelf(storage, [legacy, sourced]).ok, true);
  const loaded = loadShelf(storage).entries; assert.equal(loaded.length, 2); assert.equal(loaded[0].modelVersion, LEGACY_MODEL_VERSION); assert.equal(loaded[1].baseline, 'warm_glass_v16'); assert.equal(loaded[1].baselineConfirmed, true);
});
test('editing legacy plan can explicitly change model without duplicating or losing created date', () => {
  const legacy = draft({ modelVersion: LEGACY_MODEL_VERSION, id: 'legacy-three', createdAt: date, updatedAt: date }); delete legacy.baseline; delete legacy.baselineConfirmed;
  const edited = createRecord(pet(), legacy.id, '2026-11-26T05:00:00.000Z', legacy); const entries = upsertRecord([legacy], edited);
  assert.equal(entries.length, 1); assert.equal(entries[0].createdAt, date); assert.equal(entries[0].modelVersion, MODEL_VERSION); assert.equal(entries[0].baseline, 'warm_pet_v16');
});
test('tampered v2 source records or forged legacy source assignments are not silently accepted', () => {
  const record = createRecord(glass(), 'source-two', date);
  for (const value of [{ ...record, baselineConfirmed: false }, { ...record, baseline: 'fake' }, { ...record, name: 'cotton tee' }, { ...record, modelVersion: LEGACY_MODEL_VERSION }]) assert.equal(isRecord(value), false);
  const noModel = { ...record }; delete noModel.baseline; assert.equal(isRecord(noModel), false);
});
test('source HTML export contains exact factor units/date/cases/hash and no all-author blanket claim', () => {
  const html = buildReport(glass());
  for (const text of ['0.53 / 0.60 MTCO2e / US short ton of material', 'December 2023', 'current-mix', '907.1847', 'SOURCE-BACKED', '4771c13639ded5e979eeb037e9895493750096e76b84631796fbb6d445cbf473', 'not measured, net or marginal']) assert.ok(html.includes(text), text);
  assert.ok(!html.includes('All numerical defaults are author-set')); assert.ok(!html.includes('1000–5000 L/kg'));
});
test('source HTML export explicitly describes resin-only and not-modelled water/components', () => {
  const html = buildReport(pet());
  for (const text of ['2.17 / 2.21 MTCO2e', 'extrusion/conversion', 'cap/label', 'Water not modelled', 'green/blue/grey', 'not statistical confidence']) assert.ok(html.includes(text), text);
});
test('source poster retains exact published values, scope and not-measured label safely', () => {
  const svg = buildPoster(pet({ notes: '<script>alert(1)</script>' }));
  assert.match(svg, /2\.17 \/ 2\.21 MTCO2e\/US short ton/); assert.match(svg, /PET RESIN ONLY/); assert.match(svg, /SOURCE-BACKED REFERENCE/); assert.match(svg, /Water: not modelled/); assert.ok(!svg.includes('<script'));
});
test('source-backed reports still escape unusual user names and reject unconfirmed exports', () => {
  const html = buildReport(glass({ name: 'Glass jar <img src=x onerror=alert(1)>' })); assert.ok(html.includes('&lt;img')); assert.ok(!html.includes('<img'));
  assert.throws(() => buildPoster(pet({ baselineConfirmed: false })), RangeError);
});
test('retained public numeric evidence verifies bytes/hash, exact quotes and live HTTP records', async () => {
  const value = await verifySourceEvidence(); assert.equal(value.verifiedSources, 3); assert.equal(value.verifiedQuotes, 14); assert.equal(value.networkRequests, 0); assert.equal(value.baselines.length, 2);
});
