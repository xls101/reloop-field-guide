import test from 'node:test';
import assert from 'node:assert/strict';
import { escapeHtml } from '../lib/model.js';
import { buildPoster, buildReport, filenameFor, wrapText } from '../lib/report.js';
import { draft } from './fixture.js';
const malicious = '</script><img src=x onerror="alert(1)"> & <svg/onload=alert(2)>';

test('text escaping encodes HTML/XML delimiters and quotes', () => {
  assert.equal(escapeHtml('<>&"\''), '&lt;&gt;&amp;&quot;&#39;'); assert.equal(escapeHtml('a\0b'), 'ab');
});
test('report escapes item, location, note and title without embedding user markup', () => {
  const result = buildReport(draft({ name: malicious, city: '<b>Oxford</b>', notes: malicious }));
  assert.ok(result.includes(escapeHtml(malicious))); assert.ok(!result.includes('<img')); assert.ok(!result.includes('<script')); assert.ok(result.includes('&lt;b&gt;Oxford&lt;/b&gt;'));
});
test('report is self-contained, script-free, photo-free and has a restrictive CSP', () => {
  const result = buildReport(draft({ photo: 'data:secret', apiKey: 'secret' }));
  assert.match(result, /Content-Security-Policy/); assert.match(result, /default-src &#|default-src 'none'/); assert.ok(!result.includes('data:secret')); assert.ok(!result.includes('apiKey')); assert.ok(!/<(?:img|script|iframe)\b/i.test(result)); assert.match(result, /LOCAL_ONLY/);
});
test('report includes exact inputs, factor provenance, formula, caveats and all source URLs', () => {
  const result = buildReport(draft({ quantity: 2, displacement: 25, mass: 0.4, price: 15, cost: 4, notes: 'Remember to mend it.' }));
  for (const fragment of ['0.4 kg', '25%', '15 USD', '4 USD', '5–20 kg CO₂e/kg', 'Author assumption', 'not statistical confidence', 'ghgprotocol.org/product-standard', 'waterfootprint.org', 'gov.uk/recycling-collections', 'Remember to mend it.']) assert.ok(result.includes(fragment), fragment);
});
test('completion is recorded as a user assertion, never verified savings', () => {
  assert.match(buildReport(draft({ completedSteps: [true, false, false] })), /not independently verified/);
});
test('recycling export explicitly says no CO2/water model', () => {
  assert.match(buildReport(draft({ action: 'recycle' })), /Recycling needs local processing data/);
});
test('poster emits standalone SVG with safely escaped dynamic text and no active content', () => {
  const result = buildPoster(draft({ name: '<svg/onload=alert(1)>', notes: malicious }));
  assert.match(result, /^<svg xmlns=/); assert.match(result, /&lt;svg\/onload=alert\(1\)&gt;/); assert.ok(!result.includes('<script')); assert.ok(!result.includes('<foreignObject')); assert.ok(!result.includes('<image')); assert.match(result, /NOT MEASURED SAVINGS/); assert.match(result, /Factors assumed/);
});
test('long and Unicode names wrap inside bounded poster text', () => {
  assert.deepEqual(wrapText('abcdefghijklmnop', 5, 2), ['abcde', 'fghi…']);
  assert.equal(wrapText('物品'.repeat(50), 24, 3).length, 3); assert.ok(wrapText('word '.repeat(30), 24, 3)[2].endsWith('…'));
});
test('filenames never contain path traversal or script characters', () => {
  const name = filenameFor('../../<img src=x>.foo', 'html'); assert.match(name, /^reloop-[a-z0-9-]+\.html$/); assert.ok(!name.includes('..'));
  assert.equal(filenameFor('物品', 'svg'), 'reloop-item.svg'); assert.throws(() => filenameFor('item', 'js'), RangeError);
});
test('invalid and unconfirmed plans cannot export', () => {
  assert.throws(() => buildReport(draft({ confirmed: false })), RangeError); assert.throws(() => buildPoster(draft({ mass: NaN })), RangeError); assert.throws(() => buildReport(draft(), { createdAt: 'not a date' }), RangeError);
});
