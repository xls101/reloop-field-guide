import test from 'node:test';
import assert from 'node:assert/strict';
import { once } from 'node:events';
import { readFile } from 'node:fs/promises';
import { APP_ROOT, makeServer } from '../scripts/serve.js';
import { PUBLIC_FILES } from '../scripts/prepare-site.js';
import path from 'node:path';
async function serve(t, base = '/reloop/') { const server = makeServer({ base }); server.listen(0, '127.0.0.1'); await once(server, 'listening'); t.after(() => new Promise(resolve => server.close(resolve))); return 'http://127.0.0.1:' + server.address().port; }

test('loopback server supports root and nested Pages asset paths with correct MIME', async t => {
  const origin = await serve(t); for (const [file, type] of [['', 'text/html'], ['styles.css', 'text/css'], ['app.js', 'text/javascript'], ['lib/model.js', 'text/javascript'], ['assets/mark.svg', 'image/svg+xml'], ['manifest.webmanifest', 'application/manifest+json']]) { const response = await fetch(origin + '/reloop/' + file); assert.equal(response.status, 200); assert.ok(response.headers.get('content-type').startsWith(type)); }
});
test('local server does not expose git, docs, test fixtures, package files or traversal paths', async t => {
  const origin = await serve(t); for (const file of ['.git/config', 'package.json', 'evidence/source-checks.json', 'tests/fixture.js', 'scripts/serve.js', '%2e%2e%2fAGENTS.md', 'lib/../package.json']) assert.equal((await fetch(origin + '/reloop/' + file)).status, 404, file);
});
test('server allows GET/HEAD but not POST and redirects the bare base safely', async t => {
  const origin = await serve(t); assert.equal((await fetch(origin + '/reloop/', { method: 'HEAD' })).status, 200); assert.equal((await fetch(origin + '/reloop/', { method: 'POST' })).status, 405); const response = await fetch(origin + '/reloop', { redirect: 'manual' }); assert.equal(response.status, 308); assert.equal(response.headers.get('location'), '/reloop/');
});
test('server refuses invalid bases and malformed URI escaping', async t => {
  assert.throws(() => makeServer({ base: '/../' }), RangeError); const origin = await serve(t); assert.equal((await fetch(origin + '/reloop/%ZZ')).status, 400);
});
test('static build whitelist excludes private state, evidence, tests and all deployment drafts', () => {
  assert.deepEqual(PUBLIC_FILES, ['index.html', 'styles.css', 'app.js', 'sw.js', 'manifest.webmanifest', 'lib', 'assets']);
  for (const privateName of ['.git', '.local', 'evidence', 'tests', 'DEVPOST_SUBMISSION_DRAFT.md']) assert.ok(!PUBLIC_FILES.includes(privateName));
});
test('app has a self-only CSP, no remote fonts/scripts and relative shell references', async () => {
  const html = await readFile(path.join(APP_ROOT, 'index.html'), 'utf8'); assert.match(html, /default-src 'self'/); assert.ok(!/(?:src|href)="https?:\/\//.test(html)); assert.match(html, /href="\.\/styles.css"/); assert.match(html, /src="\.\/app.js"/);
});
test('service worker caches only the shell and isolates this app scope', async () => {
  const sw = await readFile(path.join(APP_ROOT, 'sw.js'), 'utf8'); assert.match(sw, /self\.registration\.scope/); assert.match(sw, /key\.startsWith\(PREFIX\)/); assert.ok(!sw.includes('localStorage')); assert.ok(!sw.includes('photoUrl')); assert.match(sw, /ignoreSearch: true/);
});
