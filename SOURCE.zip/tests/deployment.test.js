import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { APP_ROOT } from '../scripts/serve.js';
import { SOURCES } from '../lib/data.js';

test('Pages configuration is manual-only, default-denied and gated in both jobs', async () => {
  const workflow = await readFile(path.join(APP_ROOT, '.github/workflows/pages.yml'), 'utf8');
  assert.match(workflow, /workflow_dispatch:/); assert.match(workflow, /default: false/); assert.equal((workflow.match(/if: inputs\.public_release_approved == true/g) || []).length, 2);
  assert.ok(!/^\s*(push|pull_request|schedule):/m.test(workflow)); assert.match(workflow, /name: github-pages/); assert.match(workflow, /node --test tests\/\*\.test\.js/); assert.match(workflow, /scripts\/prepare-site\.js/);
});
test('runtime package has no dependency install requirement', async () => {
  const pkg = JSON.parse(await readFile(path.join(APP_ROOT, 'package.json'), 'utf8')); assert.equal(pkg.dependencies, undefined); assert.equal(pkg.devDependencies, undefined); assert.equal(pkg.private, true);
});
test('all active contextual citations have actual successful source-check records', async () => {
  const evidence = JSON.parse(await readFile(path.join(APP_ROOT, 'evidence/source-checks.json'), 'utf8'));
  for (const source of SOURCES) { const record = evidence.sources.find(item => item.id === source.id && item.status === 200); assert.ok(record, source.id); assert.equal(record.finalUrl, source.url); assert.ok(Number.isFinite(Date.parse(record.retrievedAt))); }
});
test('draft/publication instructions label unresolved rules and no external readiness', async () => {
  for (const filename of ['HUMAN_GATED_DEPLOY.md', 'DEVPOST_SUBMISSION_DRAFT.md', 'DEMO_SCRIPT.md']) { const text = await readFile(path.join(APP_ROOT, filename), 'utf8'); assert.match(text, /LOCAL_ONLY/); assert.match(text, /human|Human/); }
  const licence = await readFile(path.join(APP_ROOT, 'LICENSE'), 'utf8'); assert.match(licence, /MIT License/);
});
