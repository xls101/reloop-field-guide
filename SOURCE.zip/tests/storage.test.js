import test from 'node:test';
import assert from 'node:assert/strict';
import { clearShelf, createRecord, isRecord, loadShelf, MAX_PLANS, saveShelf, STORAGE_KEY, upsertRecord } from '../lib/storage.js';
import { draft, fakeStorage } from './fixture.js';
const now = '2026-11-25T03:00:00.000Z';
const record = overrides => createRecord(draft(overrides), 'plan-one', now);

test('records are valid, bounded snapshots without photos or arbitrary fields', () => {
  const value = record({ photo: 'secret', filename: 'secret.jpg', apiKey: 'private' });
  assert.equal(isRecord(value), true); assert.ok(!('photo' in value)); assert.ok(!('filename' in value)); assert.ok(!('apiKey' in value));
});
test('empty shelf and saved shelf round-trip through browser-compatible storage', () => {
  const storage = fakeStorage(); assert.deepEqual(loadShelf(storage).entries, []); assert.equal(saveShelf(storage, [record()]).ok, true); assert.deepEqual(loadShelf(storage).entries, [record()]);
});
test('editing updates rather than duplicates and preserves the created timestamp', () => {
  const first = record(); const edited = createRecord(draft({ name: 'Mended shirt' }), first.id, '2026-11-26T03:00:00.000Z', first);
  const shelf = upsertRecord([first], edited); assert.equal(shelf.length, 1); assert.equal(shelf[0].name, 'Mended shirt'); assert.equal(shelf[0].createdAt, now); assert.notEqual(shelf[0].updatedAt, now);
});
test('new records are added without silently dropping existing plans', () => {
  const shelf = [record()]; const second = createRecord(draft(), 'plan-two', now); assert.equal(upsertRecord(shelf, second).length, 2); assert.equal(shelf.length, 1);
});
test('full shelf rejects additions rather than silently evicting user data', () => {
  const shelf = Array.from({ length: MAX_PLANS }, (_, i) => createRecord(draft(), 'plan-' + i, now)); assert.throws(() => upsertRecord(shelf, createRecord(draft(), 'extra-plan', now)), /full/);
});
test('corrupt or unsupported shelf is preserved and cannot be overwritten by saving', () => {
  for (const raw of ['broken-json', 'null', JSON.stringify({ version: 9, entries: [] }), JSON.stringify({ version: 1, entries: [{ id: 'bad' }] })]) {
    const storage = fakeStorage({ [STORAGE_KEY]: raw }); assert.equal(loadShelf(storage).mode, 'corrupt'); assert.equal(saveShelf(storage, [record()]).ok, false); assert.equal(storage.getItem(STORAGE_KEY), raw);
  }
});
test('invalid identity, dates, version, category and duplicate records are rejected', () => {
  for (const overrides of [{ id: '../bad' }, { updatedAt: 'bad' }, { modelVersion: 'fake' }, { category: 'constructor' }, { completedSteps: [true] }]) assert.equal(isRecord({ ...record(), ...overrides }), false);
  assert.equal(saveShelf(fakeStorage(), [record(), record()]).ok, false);
});
test('quota failure is explicit, with no false persistent-save result', () => {
  const storage = { getItem: () => null, setItem: () => { throw Object.assign(new Error('quota'), { name: 'QuotaExceededError' }); } };
  const result = saveShelf(storage, [record()]); assert.equal(result.ok, false); assert.equal(result.mode, 'unavailable'); assert.match(result.message, /tab only/);
});
test('blocked storage reports unavailable without crashing', () => {
  const storage = { getItem: () => { throw Object.assign(new Error('blocked'), { name: 'SecurityError' }); }, setItem: () => { throw new Error('blocked'); }, removeItem: () => { throw new Error('blocked'); } };
  assert.equal(loadShelf(storage).mode, 'unavailable'); assert.equal(saveShelf(storage, [record()]).ok, false); assert.equal(clearShelf(storage).ok, false);
});
test('reset clears only ReLoop data, never other browser storage', () => {
  const storage = fakeStorage({ [STORAGE_KEY]: 'corrupt', unrelated: 'keep' }); assert.equal(clearShelf(storage).ok, true); assert.equal(storage.getItem(STORAGE_KEY), null); assert.equal(storage.getItem('unrelated'), 'keep');
});
