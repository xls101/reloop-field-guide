import test from 'node:test';
import assert from 'node:assert/strict';
import { CATEGORIES } from '../lib/data.js';
import { calculateScenario, formatMoney, formatRange, getGuide, getLocationAdvice, hazardFor, suggestCategory, validateDraft } from '../lib/model.js';
import { draft } from './fixture.js';

test('typed keyword hints recognise supported names, not photos', () => {
  for (const [name, category] of [['cotton T-SHIRT', 'textile'], ['old laptop', 'electronics'], ['wooden chair', 'furniture'], ['empty glass jar', 'glass'], ['plastic storage box', 'plastic'], ['paperback book', 'paper']]) assert.equal(suggestCategory(name), category);
  assert.equal(suggestCategory('photo-238.jpg'), null);
});
test('word boundaries avoid tablet/table and bookcase/book confusion', () => {
  assert.equal(suggestCategory('tablet'), 'electronics');
  assert.equal(suggestCategory('bookcase'), 'furniture');
  assert.equal(suggestCategory('tablecloth'), 'textile');
});
test('ambiguous and unrecognised names require a manual choice', () => {
  assert.equal(suggestCategory('glass and plastic item'), null);
  assert.equal(suggestCategory('mystery object'), null);
});
test('hazardous names yield a conservative unknown hint', () => {
  for (const name of ['swollen phone battery', 'paint can', 'mouldy shirt', 'cracked glass jar']) assert.equal(suggestCategory(name), 'unknown');
});
test('confirmation is mandatory, even with a correct keyword hint', () => {
  assert.equal(validateDraft(draft({ confirmed: false })).ok, false);
  assert.equal(validateDraft(draft({ confirmed: 'true' })).ok, false);
});
test('valid drafts normalise names and numbers without dropping notes', () => {
  const result = validateDraft(draft({ name: '  cotton   tee  ', quantity: '2', notes: 'note\nline' }));
  assert.equal(result.ok, true); assert.equal(result.value.name, 'cotton tee'); assert.equal(result.value.quantity, 2); assert.equal(result.value.notes, 'note\nline');
});
test('invalid choice keys and object-prototype properties are rejected', () => {
  for (const field of ['category', 'action', 'region', 'currency', 'condition']) assert.equal(validateDraft(draft({ [field]: 'constructor' })).ok, false);
});
test('all numerical ranges reject empty, non-finite, negative and out-of-bound values', () => {
  for (const field of ['quantity', 'mass', 'price', 'cost', 'displacement']) for (const value of ['', ' ', undefined, null, NaN, Infinity, -1, [], true, 'abc']) assert.equal(validateDraft(draft({ [field]: value })).ok, false, field + ': ' + String(value));
  for (const [field, value] of [['quantity', 101], ['mass', 1001], ['price', 1000001], ['cost', 1000001], ['displacement', 101]]) assert.equal(validateDraft(draft({ [field]: value })).ok, false);
});
test('quantity and displacement require integers; zero price/cost and displacement are valid', () => {
  assert.equal(validateDraft(draft({ quantity: 1.5 })).ok, false);
  assert.equal(validateDraft(draft({ displacement: 50.5 })).ok, false);
  assert.equal(validateDraft(draft({ price: 0, cost: 0, displacement: 0 })).ok, true);
});
test('text lengths and unsupported control characters are bounded', () => {
  for (const overrides of [{ name: 'x' }, { name: 'x'.repeat(101) }, { city: 'x'.repeat(81) }, { notes: 'x'.repeat(501) }, { name: 'bad\0item' }]) assert.equal(validateDraft(draft(overrides)).ok, false);
});
test('known scenario applies units, mass, quantity and displacement correctly', () => {
  const value = calculateScenario(draft());
  assert.deepEqual(value.carbon, [0.625, 2.5]); assert.deepEqual(value.water, [125, 625]); assert.equal(value.money, 9.5); assert.equal(value.modelled, true);
  assert.match(value.factors.status, /not sourced/i);
});
test('a zero-displacement scenario has zero production avoided, but still includes cost', () => {
  const value = calculateScenario(draft({ displacement: 0 }));
  assert.deepEqual(value.carbon, [0, 0]); assert.deepEqual(value.water, [0, 0]); assert.equal(value.money, -3);
});
test('quantity and mass scale ranges linearly; costs are per item', () => {
  const value = calculateScenario(draft({ quantity: 2, mass: 0.5, price: 20, cost: 3, displacement: 100 }));
  assert.deepEqual(value.carbon, [5, 20]); assert.deepEqual(value.water, [1000, 5000]); assert.equal(value.money, 34);
});
test('displacement is monotonic for every supported modelled category', () => {
  for (const [category, config] of Object.entries(CATEGORIES)) {
    if (!config.carbon) continue;
    let previous = -1;
    for (const displacement of [0, 25, 50, 75, 100]) {
      const value = calculateScenario(draft({ category, displacement }));
      assert.ok(value.carbon[0] >= previous); assert.ok(value.carbon[1] >= value.carbon[0]); previous = value.carbon[0];
    }
  }
});
test('recycling has no made-up CO2/water credit and counts only the entered route cost', () => {
  const value = calculateScenario(draft({ action: 'recycle', displacement: 100 }));
  assert.equal(value.modelled, false); assert.equal(value.carbon, null); assert.equal(value.water, null); assert.equal(value.money, -3);
});
test('unidentified and unsafe items have no environmental or spending estimate', () => {
  for (const overrides of [{ category: 'unknown' }, { condition: 'unsafe' }, { name: 'swollen battery', category: 'electronics' }]) {
    const value = calculateScenario(draft(overrides)); assert.equal(value.carbon, null); assert.equal(value.water, null); assert.equal(value.money, null);
  }
});
test('invalid arithmetic input throws instead of becoming NaN or silently clamping', () => {
  assert.throws(() => calculateScenario(draft({ mass: 'bad' })), RangeError);
});
test('negative spending differences are retained, not relabelled as savings', () => {
  assert.equal(calculateScenario(draft({ price: 10, cost: 30, displacement: 100 })).money, -20);
  assert.match(formatMoney(-20, 'USD'), /-/);
});
test('each material and route produces exactly three nonempty steps', () => {
  for (const category of Object.keys(CATEGORIES)) for (const action of ['repair', 'reuse', 'donate', 'recycle']) {
    const guide = getGuide(draft({ category, action, name: CATEGORIES[category].example }));
    assert.equal(guide.steps.length, 3); assert.ok(guide.steps.every(step => step.title && step.body)); assert.ok(guide.safety);
  }
});
test('guidance includes item-specific denim, laptop and chair instructions', () => {
  assert.match(getGuide(draft({ name: 'old jeans' })).steps[1].body, /denim/);
  assert.match(getGuide(draft({ name: 'laptop', category: 'electronics' })).steps[1].body, /laptop/);
  assert.match(getGuide(draft({ name: 'desk chair', category: 'furniture' })).steps[1].body, /chair/);
});
test('hazard routing overrides a requested DIY or donation plan', () => {
  for (const action of ['repair', 'donate']) { const guide = getGuide(draft({ name: 'damaged battery', category: 'electronics', action })); assert.match(guide.title, /safe route/); assert.match(guide.steps[0].body, /Do not dismantle/); }
  assert.equal(hazardFor('painted chair'), null);
});
test('England/Wales and US caveats never assert a live collection or broad UK coverage', () => {
  assert.match(getLocationAdvice(draft({ region: 'ew', city: 'Oxford' })).text, /Oxford/);
  assert.match(getLocationAdvice(draft({ region: 'ew' })).text, /England and Wales only/);
  assert.match(getLocationAdvice(draft({ region: 'us' })).text, /not local acceptance/);
  assert.match(getLocationAdvice(draft()).text, /No local collection has been verified/);
});
test('UI formatting is explicitly low-precision and preserves unmodelled values', () => {
  assert.equal(formatRange([0.625, 2.5]), '0.63–2.5'); assert.equal(formatRange(null), 'Not modelled'); assert.equal(formatRange([0, 0]), '0');
});
